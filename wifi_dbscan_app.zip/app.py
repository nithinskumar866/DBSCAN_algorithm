from flask import Flask, render_template, request, url_for
import joblib, os, json, pandas as pd, numpy as np, math
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

app = Flask(__name__)
SCALER_PATH = 'models/scaler.pkl'
SUMMARY_PATH = 'models/cluster_summary.json'
DATA_PATH = 'data/wifi_readings.csv'

scaler = None
cluster_summary = []

def load_resources():
    global scaler, cluster_summary
    if os.path.exists(SCALER_PATH):
        scaler = joblib.load(SCALER_PATH)
    if os.path.exists(SUMMARY_PATH):
        with open(SUMMARY_PATH,'r') as f:
            cluster_summary = json.load(f)

def haversine(lat1, lon1, lat2, lon2):
    R = 6371000
    phi1 = math.radians(lat1); phi2 = math.radians(lat2)
    dphi = math.radians(lat2-lat1); dlambda = math.radians(lon2-lon1)
    a = math.sin(dphi/2)**2 + math.cos(phi1)*math.cos(phi2)*math.sin(dlambda/2)**2
    return 2*R*math.asin(math.sqrt(a))

@app.route('/', methods=['GET','POST'])
def index():
    load_resources()
    if request.method == 'POST':
        try:
            lat = float(request.form.get('lat'))
            lon = float(request.form.get('lon'))
            rssi = float(request.form.get('rssi_dbm'))
            devices = int(request.form.get('device_count'))
        except Exception as e:
            return f'Invalid input: {e}', 400

        assigned = {'cluster': -1, 'distance_m': None, 'note': 'No hotspot detected (noise)'}
        if scaler is None or not cluster_summary:
            return render_template('result.html', assigned=assigned)

        best = None; best_d = 1e12
        for c in cluster_summary:
            d = haversine(lat, lon, c['center_lat'], c['center_lon'])
            if d < best_d:
                best_d = d; best = c
        if best and best_d <= 150:
            assigned = {'cluster': int(best['cluster']), 'distance_m': round(best_d,1), 'note': f"Belongs to hotspot {best['cluster']} (approx {best['count']} readings)"}
        else:
            assigned = {'cluster': -1, 'distance_m': round(best_d,1) if best else None, 'note': 'No hotspot detected (noise / outlier)'}

        df = pd.read_csv(DATA_PATH)
        plt.figure(figsize=(7,7))
        labs = df['cluster'].unique()
        for lab in sorted([l for l in labs if l!=-1]):
            mask = df['cluster']==lab
            plt.scatter(df.loc[mask,'lon'], df.loc[mask,'lat'], s=10, alpha=0.6, label=f'Cluster {lab}')
        plt.scatter(df.loc[df['cluster']==-1,'lon'], df.loc[df['cluster']==-1,'lat'], s=6, alpha=0.4, color='grey', label='Noise')
        for c in cluster_summary:
            plt.scatter(c['center_lon'], c['center_lat'], marker='*', s=160, c='yellow', edgecolors='k')
        plt.scatter(lon, lat, s=180, c='red', marker='X', edgecolors='k', linewidths=1.5, label='You')
        plt.xlabel('Longitude'); plt.ylabel('Latitude')
        plt.title('Wi-Fi Hotspot Map (your location highlighted)')
        plt.legend(fontsize=8)
        plt.tight_layout()
        os.makedirs('static/plots', exist_ok=True)
        plot_path = os.path.join('static','plots','user_map.png')
        plt.savefig(plot_path, dpi=150)
        plt.close()

        return render_template('result.html', assigned=assigned, plot_url=plot_path)
    else:
        ranges = {'lat_min':37.74, 'lat_max':37.80, 'lon_min':-122.445, 'lon_max':-122.395, 'rssi_min':-100, 'rssi_max':-20}
        return render_template('index.html', ranges=ranges)

if __name__ == '__main__':
    load_resources()
    app.run(host='0.0.0.0', port=5400, debug=True)
