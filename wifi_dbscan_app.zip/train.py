import numpy as np
import pandas as pd
from sklearn.cluster import DBSCAN
from sklearn.preprocessing import StandardScaler
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import joblib, os, json

os.makedirs('data', exist_ok=True)
os.makedirs('models', exist_ok=True)
os.makedirs('static/plots', exist_ok=True)

np.random.seed(42)

# Simulate readings within a city-like bounding box
N = 1200
hotspot_centers = [
    (37.775, -122.418, -40),
    (37.788, -122.405, -45),
    (37.765, -122.435, -50)
]
points = []
for (clat, clon, crssi) in hotspot_centers:
    k = 300
    lats = np.random.normal(clat, 0.002, k)
    lons = np.random.normal(clon, 0.002, k)
    rssi = np.random.normal(crssi, 4, k)
    for lat, lon, r in zip(lats, lons, rssi):
        points.append([lat, lon, r, np.random.randint(1,8)])

m = 300
lats = np.random.uniform(37.74,37.80,m)
lons = np.random.uniform(-122.445,-122.395,m)
rssi = np.random.normal(-80,8,m)
for lat, lon, r in zip(lats, lons, rssi):
    points.append([lat, lon, r, np.random.randint(0,4)])

df = pd.DataFrame(points, columns=['lat','lon','rssi_dbm','device_count'])
df.to_csv('data/wifi_readings.csv', index=False)

X = df[['lat','lon','rssi_dbm','device_count']].values
scaler = StandardScaler()
Xs = scaler.fit_transform(X)

db = DBSCAN(eps=0.35, min_samples=15, metric='euclidean')
labels = db.fit_predict(Xs)
df['cluster'] = labels

joblib.dump(scaler, 'models/scaler.pkl')

cluster_summary = []
unique_labels = sorted([l for l in set(labels) if l != -1])
for lab in unique_labels:
    subset = df[df['cluster']==lab]
    center = subset[['lat','lon']].mean().to_list()
    avg_rssi = subset['rssi_dbm'].mean()
    avg_devices = subset['device_count'].mean()
    cluster_summary.append({'cluster': int(lab), 'center_lat': float(center[0]), 'center_lon': float(center[1]), 'avg_rssi': float(avg_rssi), 'avg_devices': float(avg_devices), 'count': int(len(subset))})

with open('models/cluster_summary.json','w') as f:
    json.dump(cluster_summary, f, indent=2)

df.to_csv('models/wifi_labeled.csv', index=False)
df.sample(50, random_state=1).to_csv('models/sample_readings.csv', index=False)

plt.figure(figsize=(8,8))
palette = plt.cm.get_cmap('tab10', len(unique_labels)+1)
for lab in unique_labels:
    mask = df['cluster']==lab
    plt.scatter(df.loc[mask,'lon'], df.loc[mask,'lat'], s=12, alpha=0.7, label=f'Cluster {lab}')
noise = df['cluster']==-1
plt.scatter(df.loc[noise,'lon'], df.loc[noise,'lat'], s=8, alpha=0.5, color='grey', label='Noise')
for c in cluster_summary:
    plt.scatter(c['center_lon'], c['center_lat'], marker='*', s=200, edgecolors='k', linewidths=1.2, c='yellow')
    plt.text(c['center_lon']+0.0004, c['center_lat']+0.0004, f"Hotspot {c['cluster']}", fontsize=9, weight='bold')
plt.xlabel('Longitude')
plt.ylabel('Latitude')
plt.title('Wi-Fi Hotspot Clusters (DBSCAN)')
plt.legend(markerscale=2, fontsize=8)
plt.tight_layout()
plt.savefig('static/plots/cluster_map.png', dpi=150)
plt.close()

print('Generated data, ran DBSCAN, saved artifacts.')
